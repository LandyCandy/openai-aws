import numpy as np

e = np.e
inf = np.inf
nan = np.nan
pi = np.pi
